import axios from 'axios';
import { useEffect, useState } from 'react';

async function fetchPokemon() {
    try {
        const resp = await axios.get('https://pokeapi.co/api/v2/pokemon');
        return resp.data.results;
    } catch (e) {
        console.error(e);
    }
}


function Pokemon() {
    const [pokemonList, setPokemonList] = useState([]);
    

    useEffect( () => {
        const list =  fetchPokemon();
        setPokemonList(list);
        console.log('triggered!');
    }, []);

    return (
        <div>
            <ul>
                {
                    pokemonList.map((pokemon, idx) => <li key={idx}>{pokemon.name}</li>)
                }
            </ul>
            
        </div>
    );
}

export default Pokemon;